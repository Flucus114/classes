package com.classselector;

import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class SkillEvents {
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) SkillManager.sync(p, false);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("skills")
                // /skills -> abre a árvore de habilidades (qualquer jogador)
                .executes(c -> {
                    SkillManager.sync(c.getSource().getPlayerOrException(), true);
                    return 1;
                })
                // /skills reset <jogador> -> apaga as habilidades desbloqueadas (OP)
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            PlayerSkillData pd = PlayerSkillData.get(t.server);
                            pd.players.remove(t.getUUID());
                            pd.setDirty();
                            SkillManager.sync(t, false);
                            c.getSource().sendSuccess(() -> Component.literal(
                                    "Habilidades de " + t.getName().getString() + " apagadas."), true);
                            return 1;
                        }))));
    }
}
